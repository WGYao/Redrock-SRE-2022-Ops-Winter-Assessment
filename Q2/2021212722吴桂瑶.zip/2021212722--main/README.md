#Q2
目前来说功能应该没有实现..

实现思路：

    调用了阿里云的SDK来获取域名解析(阿里云核心/域名SDK库
    判断当前ip地址与域名解析的ip的地址是否一致决定更新记录
    使用threading模块的Timer作为定时器?
   
   
    使用的阿里云Python SDK直接参考的阿里云官方使用手册（https://help.aliyun.com/document_detail/67117.html ）和一些奇奇怪怪的攻略？
    
  
  
  level.1.不清楚什么原因，安装不了docker..
